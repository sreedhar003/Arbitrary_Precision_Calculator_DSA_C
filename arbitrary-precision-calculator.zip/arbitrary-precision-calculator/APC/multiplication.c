/*******************************************************************************************************************************************************************
* Title             : Multiplication
* Description       : This function performs multiplication of two large numbers stored in Doubly Linked Lists.
*                     It multiplies digit-by-digit similar to manual multiplication (school method).
*                     Each intermediate product is stored in a temporary list, shifted appropriately,
*                     and added to the final result list.
*
* Prototype         : int multiplication(Dlist **head1, Dlist **tail1, 
*                                        Dlist **head2, Dlist **tail2, 
*                                        Dlist **headR);
*
* Input Parameters  : head1, tail1 – DLL for first large number
*                     head2, tail2 – DLL for second large number
*                     headR        – DLL head pointer for final result
*
* Output            : Status (SUCCESS / FAILURE)
*******************************************************************************************************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include "apc.h"

int multiplication(Dlist **head1, Dlist **tail1, Dlist **head2, Dlist **tail2, Dlist **headR)
{
    /* If any number is empty, return FAILURE */
    if (*head1 == NULL || *head2 == NULL)
        return FAILURE;

    /* Temporary lists to store intermediate results */
    Dlist *headr1 = NULL, *tailr1 = NULL;   // For single row result
    Dlist *headr2 = NULL, *tailr2 = NULL;   // For final accumulated result
    Dlist *temp2 = *tail2;                 // Pointer for second number's LSB
    Dlist *temp1;
    Dlist *tailR = NULL;

    int carry, count = 0, mul, data;

    /* Outer loop: iterate through each digit of number2 (from LSB upward) */
    while (temp2 != NULL)
    {
        temp1 = *tail1;
        carry = 0;

        /* Inner loop: multiply current digit of num2 with ALL digits of num1 */
        while (temp1 != NULL)
        {
            mul = (temp1->data * temp2->data) + carry; // multiply digits + previous carry
            carry = mul / 10;                          // new carry
            data = mul % 10;                           // digit to store

            /* Insert at beginning because we process from LSB backward */
            insert_first(&headr1, &tailr1, data);

            temp1 = temp1->prev;   // Move to previous digit of num1
        }

        /* If carry remains after finishing one row */
        if (carry > 0)
            insert_first(&headr1, &tailr1, carry);

        /* Add required number of trailing zeros (shifting like manual multiplication) */
        for (int i = 0; i < count; i++)
            insert_last(&headr1, &tailr1, 0);

        /* If final result is still empty → first intermediate row becomes final result */
        if (*headR == NULL)
        {
            *headR = headr1;
            tailR = tailr1;

            headr1 = NULL;
            tailr1 = NULL;
        }
        else
        {
            /*
             * Add intermediate result (headr1) to the existing result (*headR)
             * Store result in headr2
             */
            addition(headR, &tailR, &headr1, &tailr1, &headr2);

            /* Free intermediate list after use */
            free_lst(&headr1, &tailr1);

            /* Update final result list */
            *headR = headr2;
            tailR = *headR;

            /* Move to the end of result list */
            while (tailR->next != NULL)
                tailR = tailR->next;

            headr2 = NULL;
            tailr2 = NULL;
        }

        count++;            // Increase shift count for next row
        temp2 = temp2->prev; // Move to next digit of number2
    }

#ifdef PRINT
    /* Print the final result if PRINT macro is enabled */
    Dlist *temp = *headR;
    printf("Result: ");
    while (temp != NULL)
    {
        printf("%d", temp->data);
        temp = temp->next;
    }
    printf("\n");
#endif

    return SUCCESS;
}
