/*******************************************************************************************************************************************************************
* Title             : Subtraction
* Description       : This function performs subtraction of two large numbers stored in Doubly Linked Lists.
*                     Subtraction is performed from the least significant digit (tail) towards the head,
*                     applying borrow logic whenever needed. The result is stored in a new DLL.
*
* Prototype         : int subtraction(Dlist **head1, Dlist **tail1, Dlist **head2, Dlist **tail2, Dlist **headR);
*
* Input Parameters  : head1 - Pointer to the first node of the first number's DLL
*                     tail1 - Pointer to the last node (LSB) of the first number
*                     head2 - Pointer to the first node of the second number's DLL
*                     tail2 - Pointer to the last node (LSB) of the second number
*                     headR - Pointer that stores the head of the resultant DLL
*
* Output            : Status (SUCCESS / FAILURE)
*******************************************************************************************************************************************************************/
#include "apc.h"
#include <stdio.h>
#include <stdlib.h>

int subtraction(Dlist **head1, Dlist **tail1, Dlist **head2, Dlist **tail2, Dlist **headR)
{
    /* Start traversal from the least significant digits */
    Dlist *temp1 = *tail1;
    Dlist *temp2 = *tail2;

    int diff, borrow = 0;

    /* Continue until both lists are fully processed */
    while (temp1 != NULL || temp2 != NULL)
    {
        diff = 0;        // Reset diff each iteration
        int val1 = 0, val2 = 0;

        /* Case 1: Both digits exist */
        if (temp1 != NULL && temp2 != NULL)
        {
            val1 = temp1->data;
            val2 = temp2->data;
        }
        /* Case 2: Only list1 has digits */
        else if (temp1 != NULL)
        {
            val1 = temp1->data;
            val2 = 0;
        }
        /* Case 3: Only list2 has digits */
        else if (temp2 != NULL)
        {
            val1 = 0;
            val2 = temp2->data;
        }

        /* Apply previous borrow */
        val1 = val1 - borrow;

        /* Borrow logic: If val1 < val2, borrow from next digit */
        if (val1 < val2)
        {
            val1 = val1 + 10;   // Borrowing adds 10
            borrow = 1;
        }
        else
        {
            borrow = 0;
        }

        /* Subtract digits */
        diff = val1 - val2;

        /* Create a new node and insert at the beginning of result list */
        Dlist *newnode = malloc(sizeof(Dlist));
        newnode->data = diff;
        newnode->next = *headR;
        newnode->prev = NULL;

        if (*headR != NULL)
            (*headR)->prev = newnode;

        *headR = newnode;

        /* Move pointers backward */
        if (temp1 != NULL)
            temp1 = temp1->prev;

        if (temp2 != NULL)
            temp2 = temp2->prev;
    }

    /* Remove unnecessary leading zeros (ex: result = 000123 → 123) */
    while (*headR && (*headR)->data == 0 && (*headR)->next != NULL)
    {
        Dlist *temp = *headR;
        *headR = (*headR)->next;
        (*headR)->prev = NULL;
        free(temp);
    }

#ifdef PRINT
    /* Debug print only when PRINT is enabled */
    Dlist *temp = *headR;
    sign == 0 ? printf("Result: ") : printf("Result: -");

    while (temp != NULL)
    {
        printf("%d", temp->data);
        temp = temp->next;
    }
    printf("\n");
#endif

    return 1;   // SUCCESS
}
