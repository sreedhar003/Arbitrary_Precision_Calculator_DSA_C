
/******************************************************************************
* Project           : Arbitrary Precision Calculator (APC)
* File Name         : apc.h
* Author            : S Sreedhar
* Description       :
*   This header file contains all the structure definitions, macro constants,
*   and function prototypes required for performing arithmetic operations on
*   very large numbers using Doubly Linked Lists.
*
*   The APC supports the following operations on arbitrarily large integers:
*       → Addition
*       → Subtraction
*       → Multiplication
*       → Division
*
*   Since traditional integer data types (int, long, long long) cannot store
*   numbers beyond their size limits, each digit of a large number is stored
*   in a separate node of a Doubly Linked List. Arithmetic operations are
*   performed manually by mimicking how operations are done on paper.
*
*   This header file provides:
*       - Node structure for the Doubly Linked List
*       - Macros for comparison results and operation statuses
*       - Prototypes for all arithmetic and helper functions
*
* Usage:
*       Include this header in all source files that implement any part of the
*       APC functionality: main, addition, subtraction, multiplication, division,
*       or utility functions.
*
*************************************************************************/
#ifndef APC_H
#define APC_H

/***********************************************
 *  Constant Macros for Status and Comparison
 ***********************************************/
#define SUCCESS   0     // Operation completed successfully
#define FAILURE  -1     // Operation failed

/* Length comparison return values */
#define L_SET     2     // Length of number1 > number2
#define L_RESET  -2     // Length of number1 < number2
#define L_EQUAL   1     // Lengths are equal

/* Value comparison return values */
#define V_SET     2     // Value of number1 > number2
#define V_RESET  -2     // Value of number1 < number2
#define V_EQUAL   1     // Values are equal

/***********************************************
 *  Structure Definition for Doubly Linked List
 ***********************************************/
typedef int data_t;

/*
 * Node structure to store each digit of the large number.
 * prev: pointer to previous digit
 * data: single digit (0–9)
 * next: pointer to next digit
 */
typedef struct node
{
	struct node *prev;
	data_t data;
	struct node *next;
} Dlist;

/***********************************************
 *  Arithmetic Operation Function Prototypes
 ***********************************************/

/* Addition of two large numbers */
int addition(Dlist **head1, Dlist **tail1,Dlist **head2, Dlist **tail2,Dlist **headR);

/* Multiplication of two large numbers */
int multiplication(Dlist **head1, Dlist **tail1,Dlist **head2, Dlist **tail2,Dlist **headR);

/* Division of two large numbers */
int division(Dlist **head1, Dlist **tail1,Dlist **head2, Dlist **tail2,Dlist **headR);

/* Subtraction of two large numbers */
int subtraction(Dlist **head1, Dlist **tail1,Dlist **head2, Dlist **tail2,Dlist **headR);

/***********************************************
 *  Helper Function Prototypes
 ***********************************************/

/*
 Converts string input (argv) into a DLL representing a large number. Also determines number sign.
 */
int insert_data_first(Dlist **head, Dlist **tail, char *argv);

/* Compare lengths of two large numbers */
int length(Dlist **head1, Dlist **tail1,Dlist **head2, Dlist **tail2);

/* Compare values (digit-by-digit) of two large numbers */
int value(Dlist **head1, Dlist **tail1,Dlist **head2, Dlist **tail2);

/***********************************************
 *  Helper Functions for Multiplication
 ***********************************************/

/* Insert a digit at the beginning of DLL */
int insert_first(Dlist **head, Dlist **tail, int data);

/* Insert a digit at the end of DLL */
int insert_last(Dlist **head, Dlist **tail, int data);

/* Free a DLL completely */
void free_lst(Dlist **head, Dlist **tail);


/* Print the final result with proper sign */
void print_result(Dlist **headR, int sign);

#endif
