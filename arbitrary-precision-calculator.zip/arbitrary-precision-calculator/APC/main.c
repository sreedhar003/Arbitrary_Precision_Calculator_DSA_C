/**************************************************************************************************************************************************************
* Author      : S Sreedhar
* Title       : main function (Driver function)
* Description : This main function acts as the driver for performing Arithmetic operations 
*   			on very large integers using Doubly Linked Lists. Since normal data types 
*   			cannot store huge numbers (like 100+ digits), each digit is stored as a node 
*   			in a DLL and all operations (+, -, *, /) are implemented manually.

*   COMMAND-LINE ARGUMENT FORMAT
*       ./a.out <number1> <operator> <number2>
*
*       Example:
*           ./a.out 999999 + 888888
*           ./a.out -12345 X 567
*           ./a.out 1000000000000 / 10
***************************************************************************************************************************************************************/
#include "apc.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
    char option, operator;

    do
    {
        /* Declare list pointers for input numbers and result */
        Dlist *head1 = NULL, *tail1 = NULL;     // List for first number
        Dlist *head2 = NULL, *tail2 = NULL;     // List for second number
        Dlist *headR = NULL;                    // List for result

        /* Identify the given operator from command-line arguments */
        if (strcmp(argv[2], "+") == 0)
            operator = '+';
        if (strcmp(argv[2], "-") == 0)
            operator = '-';
        if (strcmp(argv[2], "X") == 0 || strcmp(argv[2], "x") == 0)
            operator = '*';
        if (strcmp(argv[2], "/") == 0)
            operator = '/';

        int sign1, sign2;   // To store sign (0 = +, 1 = -) of input numbers

        switch (operator)
        {
            case '+':
                /* Insert numbers into DLL and store sign */
                sign1 = insert_data_first(&head1, &tail1, argv[1]);
                sign2 = insert_data_first(&head2, &tail2, argv[3]);

                /* (+A) + (+B) → Normal addition, positive result */
                if (sign1 == 0 && sign2 == 0)
                {
                    addition(&head1, &tail1, &head2, &tail2, &headR);
                    print_result(&headR, 0);
                }

                /* (-A) + (-B) → Add magnitudes, result will be negative */
                else if (sign1 == 1 && sign2 == 1)
                {
                    addition(&head1, &tail1, &head2, &tail2, &headR);
                    print_result(&headR, 1);
                }

                /* (-A) + (+B) → Equivalent to B - A */
                else if (sign1 == 1 && sign2 == 0)
                {
                    if (length(&head1, &tail1, &head2, &tail2) == L_SET)  // |A| > |B|
                    {
                        subtraction(&head1, &tail1, &head2, &tail2, &headR);
                        print_result(&headR, 1);    // Negative result
                    }
                    else    // |B| >= |A|
                    {
                        subtraction(&head2, &tail2, &head1, &tail1, &headR);
                        print_result(&headR, 0);    // Positive result
                    }
                }
                break;

            case '-':
                /* Insert numbers for subtraction */
                insert_data_first(&head1, &tail1, argv[1]);
                insert_data_first(&head2, &tail2, argv[3]);

                /* If |A| > |B| → A - B */
                if (length(&head1, &tail1, &head2, &tail2) == L_SET)
                {
                    subtraction(&head1, &tail1, &head2, &tail2, &headR);
                    print_result(&headR, 0);
                }
                /* If |A| < |B| → B - A and result will be negative */
                else if (length(&head1, &tail1, &head2, &tail2) == L_RESET)
                {
                    subtraction(&head2, &tail2, &head1, &tail1, &headR);
                    print_result(&headR, 1);
                }
                /* |A| = |B| → Compare digit values */
                else if (length(&head1, &tail1, &head2, &tail2) == L_EQUAL)
                {
                    if (value(&head1, &tail1, &head2, &tail2) == V_SET)
                    {
                        subtraction(&head1, &tail1, &head2, &tail2, &headR);
                        print_result(&headR, 0);
                    }
                    if (value(&head1, &tail1, &head2, &tail2) == V_RESET)
                    {
                        subtraction(&head2, &tail2, &head1, &tail1, &headR);
                        print_result(&headR, 1);
                    }
                    /* Both numbers equal → result is 0 */
                    if (value(&head1, &tail1, &head2, &tail2) == V_EQUAL)
                        printf("Result = %d\n", 0);
                }
                break;

            case '*':
                /* Insert numbers & detect sign */
                sign1 = insert_data_first(&head1, &tail1, argv[1]);
                sign2 = insert_data_first(&head2, &tail2, argv[3]);

                /* Perform multiplication */
                multiplication(&head1, &tail1, &head2, &tail2, &headR);

                /* Result sign: if one number negative → result negative */
                if (sign1 == 1 || sign2 == 1)
                    print_result(&headR, 1);
                else
                    print_result(&headR, 0);

                break;

            case '/':
                /* Insert numbers for division */
                insert_data_first(&head1, &tail1, argv[1]);
                insert_data_first(&head2, &tail2, argv[3]);

                /* Perform division */
                division(&head1, &tail1, &head2, &tail2, &headR);

                /* Print quotient (sign handled inside division if needed) */
                print_result(&headR, 0);
                break;

            default:
                printf("Invalid Input :-(");
        }

    } while (option == 'y' || option == 'Y');

    return 0;
}
