/*************************************************************************
* Project           : Arbitrary Precision Calculator (APC)
* File Name         : apc_utils.c
* Author            : S Sreedhar
*
* Description       :
*   This file contains all the utility/helper functions used :
*
*       insert_data_first() : Convert input string into DLL representation
*       length()            : Compare lengths of two large numbers
*       value()             : Compare values digit-by-digit
*       insert_first()      : Insert a digit at the beginning of a DLL
*       insert_last()       : Insert a digit at the end of a DLL
*       free_lst()          : Free the entire DLL
*       print_result()      : Print the final computed result
*
*   These functions support all arithmetic operations by handling DLL creation,
*   comparison, and formatted printing.
*
******************************************************************************/

#include "apc.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

/************************************************************************************************************
* Function Name     : insert_data_first
* Description       : Converts an input string representing a large number into a Doubly Linked List.
*                     Digits are inserted one-by-one at the beginning of the list.
* Prototype         : int insert_data_first(Dlist **head, Dlist **tail, char *argv)
* Input             : char *argv  → input string number (may include '-' sign)
* Output            : sign        → 0 (positive), 1 (negative)
**************************************************************************************************************/
int insert_data_first(Dlist **head, Dlist **tail, char *argv)
{
    int data;
    int sign = 0;          // Tracks negative sign
    Dlist *newnode;
    Dlist *temp;

    /* Process digits from last char → first char (units → highest digit) */
    for (int i = strlen(argv) - 1; i >= 0; i--)
    {
        newnode = malloc(sizeof(Dlist));

        /* Check and store negative sign */
        if (argv[i] == '-')
        {
            sign = 1;
            continue;
        }

        /* Convert char to integer digit */
        data = argv[i] - '0';
        newnode->data = data;
        newnode->next = NULL;
        newnode->prev = NULL;

        /* Insert into DLL */
        if (*head == NULL)
        {
            *head = *tail = newnode;
        }
        else
        {
            (*head)->prev = newnode;
            newnode->next = *head;
            *head = newnode;
        }
    }

#ifdef DEBUG_PRINT
    temp = *head;
    while (temp != NULL)
    {
        printf("%d ", temp->data);
        temp = temp->next;
    }
#endif

    return sign;
}

/*****************************************************************************************
* Function Name     : length
* Description       : Compares lengths (number of digits) of two large numbers.
* Prototype         : int length(Dlist **head1, Dlist **tail1, Dlist **head2, Dlist **tail2)
* Output Values     : L_EQUAL, L_SET, L_RESET
**********************************************************************************************/
int length(Dlist **head1, Dlist **tail1, Dlist **head2, Dlist **tail2)
{
    Dlist *temp1 = *head1;
    Dlist *temp2 = *head2;

    int count1 = 0, count2 = 0;

    /* Count digits in number1 */
    while (temp1 != NULL)
    {
        count1++;
        temp1 = temp1->next;
    }

    /* Count digits in number2 */
    while (temp2 != NULL)
    {
        count2++;
        temp2 = temp2->next;
    }

    if (count1 == count2)
        return L_EQUAL;
    else if (count1 > count2)
        return L_SET;
    else
        return L_RESET;
}

/*******************************************************************************************
* Description       : Compares two large numbers digit-by-digit.
* Prototype         : int value(Dlist **head1, Dlist **tail1, Dlist **head2, Dlist **tail2)
* Output Values     : V_SET, V_RESET, V_EQUAL
*********************************************************************************************/
int value(Dlist **head1, Dlist **tail1, Dlist **head2, Dlist **tail2)
{
    Dlist *temp1 = *head1;
    Dlist *temp2 = *head2;

    /* Compare digits from MSD → LSD */
    while (temp1 != NULL || temp2 != NULL)
    {
        if (temp1->data > temp2->data)
            return V_SET;
        else if (temp1->data < temp2->data)
            return V_RESET;
        else
        {
            if (temp1 != NULL) temp1 = temp1->next;
            if (temp2 != NULL) temp2 = temp2->next;
        }
    }

    return V_EQUAL; // Both numbers equal
}

/*************************************************************************************
* Description       : Inserts a digit at the beginning of a Doubly Linked List.
* Prototype         : int insert_first(Dlist **head, Dlist **tail, int data)
*****************************************************************************************/
int insert_first(Dlist **head, Dlist **tail, int data)
{
    Dlist *newnode = malloc(sizeof(Dlist));
    if (newnode == NULL) return FAILURE;

    newnode->data = data;
    newnode->prev = NULL;
    newnode->next = *head;

    /* If DLL is empty */
    if (*head == NULL)
    {
        *head = *tail = newnode;
        return SUCCESS;
    }

    /* Fix backward link */
    (*head)->prev = newnode;
    *head = newnode;

#ifdef PRINT
    Dlist *temp = *head;
    while (temp != NULL)
    {
        printf("%d", temp->data);
        temp = temp->next;
    }
    printf("\n");
#endif

    return SUCCESS;
}

/***********************************************************************************************************
* Function Name     : insert_last
* Description       : Inserts a digit at the end of DLL (used for trailing zeros in multiplication).
* Prototype         : int insert_last(Dlist **head, Dlist **tail, int data)
**********************************************************************************************************/
int insert_last(Dlist **head, Dlist **tail, int data)
{
    /* DLL is empty, cannot insert 'last' */
    if (*tail == NULL)
        return FAILURE;

    Dlist *newnode = malloc(sizeof(Dlist));
    if (newnode == NULL) return FAILURE;

    newnode->data = data;
    newnode->next = NULL;
    newnode->prev = *tail;

    (*tail)->next = newnode;
    *tail = newnode;

#ifdef PRINT
    Dlist *temp = *head;
    while (temp != NULL)
    {
        printf("%d", temp->data);
        temp = temp->next;
    }
    printf("\n");
#endif

    return SUCCESS;
}

/*************************************************************************
* Function Name     : free_lst
* Description       : Frees an entire Doubly Linked List.
**************************************************************************/
void free_lst(Dlist **head, Dlist **tail)
{
    Dlist *temp = *head, *prev;

    while (temp != NULL)
    {
        prev = temp;
        temp = temp->next;
        free(prev);
    }

    *head = NULL;
    *tail = NULL;
}

/***************************************************************************************************
* Function Name     : print_result
* Description       : Prints the resultant large number with sign.
* Prototype         : void print_result(Dlist **headR, int sign)
***************************************************************************************************/
void print_result(Dlist **headR, int sign)
{
    Dlist *temp = *headR;

    /* Print sign */
    (sign == 0) ? printf("Result: ") : printf("Result: -");

    /* Print each digit */
    while (temp != NULL)
    {
        printf("%d", temp->data);
        temp = temp->next;
    }

    printf("\n");
}
