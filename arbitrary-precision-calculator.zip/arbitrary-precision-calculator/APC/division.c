/*******************************************************************************************************************************************************************
* Title             : Division
* Description       : This function performs division of two large numbers stored in Doubly Linked Lists.
*                     The algorithm follows repeated subtraction:
*                         Dividend = Dividend - Divisor
*                     until Dividend < Divisor.
*                     The number of successful subtractions gives the quotient.
*
* Prototype         : int division(Dlist **head1, Dlist **tail1, 
*                                  Dlist **head2, Dlist **tail2, 
*                                  Dlist **headR);
*
* Input Parameters  : head1, tail1 – DLL representing dividend
*                     head2, tail2 – DLL representing divisor
*                     headR        – DLL representing quotient
*
* Output            : Status (SUCCESS / FAILURE)
*******************************************************************************************************************************************************************/
#include "apc.h"
#include <stdio.h>
#include <stdlib.h>

int division(Dlist **head1, Dlist **tail1, Dlist **head2, Dlist **tail2, Dlist **headR)
{
    int res = 0;       // Quotient counter
    *headR = NULL;     // Initialize result list as empty

    /* Perform repeated subtraction until Dividend < Divisor */
    while (1)
    {
        /* If |Dividend| < |Divisor| → Stop division */
        if (length(head1, tail1, head2, tail2) == L_RESET)
            break;

        /* If |Dividend| == |Divisor| → Check actual values */
        if (length(head1, tail1, head2, tail2) == L_EQUAL)
        {
            if (value(head1, tail1, head2, tail2) == V_RESET)
                break;
        }

        /* Temporary list to store result of subtraction */
        Dlist *tempR = NULL;

        /* Dividend = Dividend - Divisor */
        subtraction(head1, tail1, head2, tail2, &tempR);

        /* Update Dividend head and tail */
        *head1 = tempR;       // new dividend head
        *tail1 = *head1;

        /* Move tail to the last node */
        while ((*tail1)->next != NULL)
            *tail1 = (*tail1)->next;

        /* Increase quotient count */
        res++;
    }

    /* If quotient is zero (dividend < divisor from start) */
    if (res == 0)
    {
        Dlist *newnode = malloc(sizeof(Dlist));
        newnode->data = 0;
        newnode->next = newnode->prev = NULL;
        *headR = newnode;
        return SUCCESS;
    }

    /* Convert integer quotient (res) into DLL representation */
    while (res > 0)
    {
        int digit = res % 10;   // Extract last digit

        /* Create new node for result digit */
        Dlist *newnode = malloc(sizeof(Dlist));
        newnode->data = digit;

        /* Insert at front of result list */
        newnode->prev = NULL;
        newnode->next = *headR;

        if (*headR != NULL)
            (*headR)->prev = newnode;

        *headR = newnode;

        res /= 10;   // Remove processed digit
    }

#ifdef PRINT
    /* Print final quotient */
    Dlist *temp = *headR;
    printf("Result: ");
    while (temp != NULL)
    {
        printf("%d", temp->data);
        temp = temp->next;
    }
    printf("\n");
#endif

    return SUCCESS;
}
