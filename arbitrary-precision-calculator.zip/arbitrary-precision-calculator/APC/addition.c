/*******************************************************************************************************************************************************************
* Title             : Addition
* Description       : This function performs addition of two given large numbers stored in Doubly Linked Lists.
*                     Digits are added from the least significant place (tail) and the result is stored in a new list.
* Prototype         : int addition(Dlist **head1, Dlist **tail1, Dlist **head2, Dlist **tail2, Dlist **headR);
* Input Parameters  : head1  - Pointer to first node of first number's DLL
*                     tail1  - Pointer to last node of first number's DLL (LSB)
*                     head2  - Pointer to first node of second number's DLL
*                     tail2  - Pointer to last node of second number's DLL (LSB)
*                     headR  - Pointer to the head node of the resultant number's DLL
* Output            : Status (SUCCESS / FAILURE)
*******************************************************************************************************************************************************************/
#include "apc.h"
#include <stdio.h>
#include <stdlib.h>

int addition(Dlist **head1, Dlist **tail1, Dlist **head2, Dlist **tail2, Dlist **headR)
{
    /* Pointers to traverse from the last digit (LSB) */
    Dlist *temp1 = *tail1;
    Dlist *temp2 = *tail2;

    int sum, carry = 0;

    /* Loop until both lists are fully traversed */
    while (temp1 != NULL || temp2 != NULL)
    {
        sum = carry;   // Start with carry from previous addition

        /* Case 1: Both nodes exist → Add both digits */
        if (temp1 != NULL && temp2 != NULL)
        {
            sum += temp1->data + temp2->data;
        }
        /* Case 2: Only list1 has remaining digits */
        else if (temp1 != NULL)
        {
            sum += temp1->data;
        }
        /* Case 3: Only list2 has remaining digits */
        else if (temp2 != NULL)
        {
            sum += temp2->data;
        }

        /* If sum exceeds 9 → retain last digit and forward carry = 1 */
        if (sum > 9)
        {
            sum = sum % 10;
            carry = 1;
        }
        else
        {
            carry = 0;
        }

        /* Move pointers to previous nodes */
        if (temp1 != NULL) temp1 = temp1->prev;
        if (temp2 != NULL) temp2 = temp2->prev;

        /* Create a new node and insert at the beginning of result list */
        Dlist *newnode = malloc(sizeof(Dlist));
        newnode->data = sum;
        newnode->next = *headR;
        newnode->prev = NULL;

        /* Fix backward link of existing head */
        if (*headR != NULL)
            (*headR)->prev = newnode;

        *headR = newnode;  // Update result head
    }

    /* After traversal, if a final carry remains → Insert at result head */
    if (carry == 1)
    {
        Dlist *newnode = malloc(sizeof(Dlist));
        newnode->data = 1;
        newnode->next = *headR;
        newnode->prev = NULL;

        if (*headR != NULL)
            (*headR)->prev = newnode;

        *headR = newnode;
    }

#ifdef PRINT
    /* Debug printing block if enabled */
    Dlist *temp = *headR;
    sign == 0 ? printf("Result: ") : printf("Result: -");

    while (temp != NULL)
    {
        printf("%d", temp->data);
        temp = temp->next;
    }
    printf("\n");
#endif
}
